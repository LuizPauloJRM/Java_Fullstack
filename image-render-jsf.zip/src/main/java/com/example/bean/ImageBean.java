package com.example.bean;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.DefaultStreamedContent;

@Named
@RequestScoped
public class ImageBean {

    public StreamedContent getImagem(String nomeArquivo) {
        try {
            Path caminho = Path.of("C:/imagens-jsf/" + nomeArquivo);
            byte[] bytes = Files.readAllBytes(caminho);

            InputStream stream = new ByteArrayInputStream(bytes);
            return DefaultStreamedContent.builder()
                    .name(nomeArquivo)
                    .contentType("image/png")
                    .stream(() -> stream)
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
